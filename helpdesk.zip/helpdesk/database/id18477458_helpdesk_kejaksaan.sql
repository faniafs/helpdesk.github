-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2022 at 05:08 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id18477458_helpdesk_kejaksaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_keluhan`
--

CREATE TABLE `tb_keluhan` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `divisi` varchar(255) NOT NULL,
  `perihal_masalah` varchar(255) NOT NULL,
  `deskripsi_masalah` longtext NOT NULL,
  `status` enum('1','0') NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_keluhan`
--

INSERT INTO `tb_keluhan` (`id`, `email`, `divisi`, `perihal_masalah`, `deskripsi_masalah`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(21, 'fania@gmail.com', 'Divisi Pidana Umum', 'Printer bermasalah', 'Printer mati', '1', '2022-02-15', '2022-02-15', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tingkatan`
--

CREATE TABLE `tb_tingkatan` (
  `id_tingkatan` int(11) NOT NULL,
  `tingkatan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_tingkatan`
--

INSERT INTO `tb_tingkatan` (`id_tingkatan`, `tingkatan`) VALUES
(1, 'Teknisi'),
(2, 'Pegawai'),
(3, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_tingkatan` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `id_tingkatan`, `created_at`, `updated_at`, `deleted_at`) VALUES
(12, 'Administrator', 'admin@gmail.com', '$2y$10$w6MKt1FqxRu8RUI.d1nSnOLcoC/gObQeRb4cJRVyNTyGTEUpt6GBa', 3, '2022-01-23', '2022-01-23', '0000-00-00'),
(13, 'Teknisi Kejari', 'teknisi@gmail.com', '$2y$10$3zYPL0BxLKu9dbTxTvEmdu5kv4j.bDzoi2DjEA5ifz/PBkCi0hdmG', 1, '2022-01-23', '2022-01-23', '0000-00-00'),
(14, 'Fania', 'fania@gmail.com', '$2y$10$dR3fEWxKxJmHedNMb.LG5.PlMiaiXd82D35bPGjHW4wp3pt96kO66', 2, '2022-02-15', '2022-02-15', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_keluhan`
--
ALTER TABLE `tb_keluhan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_tingkatan`
--
ALTER TABLE `tb_tingkatan`
  ADD PRIMARY KEY (`id_tingkatan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_tingkatan` (`id_tingkatan`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_keluhan`
--
ALTER TABLE `tb_keluhan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tb_tingkatan`
--
ALTER TABLE `tb_tingkatan`
  MODIFY `id_tingkatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_tingkatan`) REFERENCES `tb_tingkatan` (`id_tingkatan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
