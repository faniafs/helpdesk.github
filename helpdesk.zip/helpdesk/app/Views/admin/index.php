<?= $this->extend('templates/index'); ?>
<?= $this->section('page-content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Kelola Pengguna</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('backend/index'); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Kelola Pengguna</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<?php if (session()->getFlashdata('pesan')) : ?>
  <div class="alert alert-success text-center" role="alert">
    <?= session()->getFlashdata('pesan'); ?>
  </div>
<?php endif; ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Tabel Data Pengguna</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table class="table table-bordered table-striped table-hover" id="example2">
              <thead>
                <tr>
                  <th class="text-center">No</th>
                  <th class="text-center">Nama Lengkap</th>
                  <th class="text-center">Email</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; ?>
                <?php foreach ($users as $user) : ?>
                  <tr>
                    <th class=" text-center"><?= $i++; ?></th>
                    <td class="text-center"><?= $user->nama; ?></td>
                    <td class="text-center"><?= $user->email; ?></td>
                    <td class="text-center">
                      <a href="<?= base_url('admin/remove/' . $user->userid); ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin?');"><i class="fa fa-trash" aria-hidden="true">&nbsp;Hapus</i></a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>

          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->

        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>

<?= $this->endSection(); ?>