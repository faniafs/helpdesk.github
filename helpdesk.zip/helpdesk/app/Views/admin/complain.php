<?= $this->extend('templates/index'); ?>
<?= $this->section('page-content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Data Keluhan</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('backend/index'); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Tabel Keluhan</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<?php if (session()->getFlashdata('pesan')) : ?>
  <div class="alert alert-success text-center" role="alert">
    <?= session()->getFlashdata('pesan'); ?>
  </div>
<?php endif; ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Tabel Data Keluhan</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table class="table table-bordered table-striped table-hover" id="example2">
              <thead>
                <tr>
                  <th class="text-center">No</th>
                  <th class="text-center">Pengirim</th>
                  <th class="text-center">Divisi</th>
                  <th class="text-center">Perihal</th>
                  <th class="text-center">Tanggal</th>
                  <th class="text-center">Status</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; ?>
                <?php foreach ($p as $file) : ?>
                  <tr>
                    <th class="text-center"><?= $i++; ?></th>
                    <td class="text-center"><?= $file->email; ?></td>
                    <td class="text-center"><?= $file->divisi; ?></td>
                    <td class="text-center"><?= $file->perihal_masalah; ?></td>
                    <td class="text-center"><?= $file->created_at; ?></td>
                    <td class="text-center"><span class="badge badge-<?= ($file->status == '0') ? 'warning' : 'success' ?>"><?= ($file->status == '0') ? '<i class="fa fa-spinner" aria-hidden="true"></i> &nbsp Diproses ' : '<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp Selesai' ?></span></td>
                    <td class="text-center">
                      <a href="<?= base_url('admin/print/' . $file->id); ?>" class="btn btn-success"> <i class="fa fa-eye" aria-hidden="true"></i></a>
                      <a href="<?= base_url('admin/delete/' . $file->id); ?>" onclick="return confirm('Apakah Anda Yakin?');" type="button" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      <div class="btn-group" role="group">
    <button id="btnGroupDrop1" type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Status
    </button>
    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
      <a class="dropdown-item" href="<?= base_url('admin/actionProses/' . $file->id); ?>">Diproses</a>
      <a class="dropdown-item" href="<?= base_url('admin/actionSelesai/' . $file->id); ?>">Selesai</a>
    </div>
  </div>
                    </td>
                  </tr>
                <?php endforeach; ?>

              </tbody>
            </table>

          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->

        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>

<?= $this->endSection(); ?>