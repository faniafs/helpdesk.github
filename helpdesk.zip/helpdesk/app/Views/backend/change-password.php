<?= $this->extend('templates/index'); ?>
<?= $this->section('page-content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Ubah Password</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('backend/index'); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Ubah Password</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<?php if (session()->getFlashdata('pesan')) : ?>
  <div class="alert alert-success text-center" role="alert">
    <?= session()->getFlashdata('pesan'); ?>
  </div>
<?php endif; ?>
<section class="content">
  <div class="container-fluid">
    <div class="card">
      <!-- /.card-header -->
      <div class="card-body">
        <form action="<?= base_url('backend/change/' . session()->id); ?>" method="post">
          <div class="mb-3">
            <label for="pass1" class="form-label">Password Lama</label>
            <input type="password" class="form-control" id="pass1" name="current_password" required>
          </div>
          <div class="mb-3">
            <label for="pass2" class="form-label">Password Baru</label>
            <input type="password" class="form-control" id="pass2" name="new_password1" required>
          </div>
          <div class="mb-5">
            <label for="pass3" class="form-label ">Ulangi Password</label>
            <input type="password" class="form-control" id="pass3" name="new_password2" required>
          </div>
          <button type="submit" class="btn btn-success mt-3 btn-user btn-block">Ubah Password</button>

        </form>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
</section>

<?= $this->endSection(); ?>