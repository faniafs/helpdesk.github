<?= $this->extend('templates/index'); ?>
<?= $this->section('page-content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Dashboard</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<?php if (session()->getFlashdata('pesan')) : ?>
  <div class="alert alert-success text-center" role="alert">
    <?= session()->getFlashdata('pesan'); ?>
  </div>
<?php endif; ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-6">
        <div class="small-box bg-success">
          <div class="inner">
            <h3><?= $total_user; ?></h3>

            <p>Jumlah Pengguna</p>
          </div>
          <div class="icon">
            <i class="fas fa-user"></i>
          </div>
          <?php if (allow('3')) : ?>
            <a href="<?= base_url('admin/index'); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
          <?php endif; ?>
        </div>
      </div>
      <div class="col 6">
        <div class="small-box bg-success">
          <div class="inner">
            <h3><?= $total_keluhan; ?></h3>

            <p>Jumlah Keluhan</p>
          </div>
          <div class="icon">
            <i class="fas fa-file"></i>
          </div>
          <?php if (allow('1')) : ?>
            <a href="<?= base_url('admin/complain'); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
          <?php endif; ?>
        </div>

      </div>
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>

<?= $this->endSection(); ?>