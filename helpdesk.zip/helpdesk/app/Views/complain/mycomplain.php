<?= $this->extend('templates/index'); ?>
<?= $this->section('page-content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Keluhan Anda</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('backend/index'); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Keluhan Anda</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<?php if (session()->getFlashdata('pesan')) : ?>
  <div class="alert alert-success text-center" role="alert">
    <?= session()->getFlashdata('pesan'); ?>
  </div>
<?php endif; ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Tabel Keluhan Anda</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table class="table table-bordered table-striped table-hover" id="example2">
              <thead>
                <tr>
                  <th class="text-center">No</th>
                  <th class="text-center">Perihal Masalah</th>
                  <th class="text-center">Tanggal</th>
                  <th class="text-center">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; ?>
                <?php foreach ($p as $file) : ?>
                  <tr>
                    <th class="text-center"><?= $i++; ?></th>
                    <td class="text-center"><?= $file->perihal_masalah; ?></td>
                    <td class="text-center"><?= $file->created_at; ?></td>
                    <td class="text-center"><span class="badge badge-<?= ($file->status == '0') ? 'warning' : 'success' ?>"><?= ($file->status == '0') ? '<i class="fa fa-spinner" aria-hidden="true"></i> &nbsp Diproses ' : '<i class="fa fa-check-circle" aria-hidden="true"></i> &nbsp Selesai' ?></span></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>

          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->

        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>

<?= $this->endSection(); ?>