<?= $this->extend('templates/index'); ?>
<?= $this->section('page-content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Form Keluhan</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('backend/index'); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Form Keluhan</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<?php if (session()->getFlashdata('pesan')) : ?>
  <div class="alert alert-success text-center" role="alert">
    <?= session()->getFlashdata('pesan'); ?>
  </div>
<?php endif; ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header text-center">
            <h3 class="card-title">Jika Punya Keluhan Silahkan Isi Dibawah Ini</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <form action="<?= base_url('/complain/savep'); ?>" method="post" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="judul" class="form-label">Divisi</label>
                <select class="form-control" id="kepada" name="divisi" autofocus required>
                  <option selected>--Pilih--</option>
                  <option value="Divisi Intelijen">Divisi Intelijen</option>
                  <option value="Divisi Pidana Umum">Divisi Pidana Umum</option>
                  <option value="Divisi Pidana Khusus">Divisi Pidana Khusus</option>
                  <option value="Divisi Perdata dan Tata Usaha Negara">Divisi Perdata dan Tata Usaha Negara</option>
                  <option value="Divisi Barang Bukti">Divisi Barang Bukti</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="perihal" class="form-label">Perihal Masalah</label>
                <input type="text" class="form-control" id="perihal" name="perihal_masalah" autofocus required>
                <input type="hidden" value="<?= session()->email; ?>" name="email">
              </div>
              <div class="mb-3">
                <label for="subject" class="form-label">Deskripsi Masalah</label>
                <div class="form-group">
                  <textarea id="compose-textarea" class="form-control" style="height: 300px" name="deskripsi_masalah">
            </textarea>
                </div>
                <input type="hidden" class="form-control" id="status" name="status" value="0">
                <button type="submit" class="btn btn-success mt-3 btn-user btn-block">Kirim </button>
            </form>
          </div>

        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

      <!-- /.card -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>

<?= $this->endSection(); ?>