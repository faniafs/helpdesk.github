<?php

namespace App\Models;

use CodeIgniter\Model;

class BackendModel extends Model
{
    protected $table      = 'users';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $allowedFields = ['nama', 'email', 'gambar', 'password', 'id_tingkatan'];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    public function hitungJumlahUsers()
    {
        return $this->db->table('users')->countAll();
    }
    public function hitungJumlahKeluhan()
    {
        return $this->db->table('tb_keluhan')->countAll();
    }
}
