<?php

namespace App\Models;

use CodeIgniter\Model;

class ComplainModel extends Model
{
    protected $table      = 'tb_keluhan';
    protected $allowedFields = ['email', 'divisi', 'perihal_masalah', 'deskripsi_masalah', 'status'];
    protected $returnType = 'object';
    protected $useTimestamps = true;
}
