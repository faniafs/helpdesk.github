<?php

namespace App\Controllers;

use App\Models\UsersModel;
use App\Models\AuthModel;

class Auth extends BaseController
{
    public function __construct()
    {
        $this->userModel = new UsersModel();
        $this->authModel = new AuthModel();
    }
    public function register()
    {
        $data = [
            'nama' => $this->request->getVar('nama'),
            'email' => $this->request->getVar('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'id_tingkatan' => 2
        ];
        $this->userModel->insert($data);
        session()->setFlashdata('pesan', 'Akun Berhasil Dibuat');
        return redirect()->to('/');
    }
    public function login()
    {
        $table = 'users';
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $row = $this->authModel->get_data_login($email, $table);
        if ($row == NULL) {
            session()->setFlashdata('gagal', 'Email Anda Salah!!');
            return redirect()->to('/');
        }
        if (password_verify($password, $row->password)) {
            $data = array(
                'log' => TRUE,
                'id' => $row->id,
                'nama' => $row->nama,
                'email' => $row->email,
                'id_tingkatan' => $row->id_tingkatan
            );
            session()->set($data);
            session()->setFlashdata('pesan', 'Selamat Datang');
            return redirect()->to('/backend');
        }
        session()->setFlashdata('gagal', 'Password Anda Salah');
        return redirect()->to('/');
    }
    public function logout()
    {
        $session = session();
        $session->destroy();
        session()->setFlashdata('pesan', 'Berhasil Logout');
        return redirect()->to('/');
    }
}
