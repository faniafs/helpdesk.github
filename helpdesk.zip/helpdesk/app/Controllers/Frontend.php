<?php

namespace App\Controllers;

class Frontend extends BaseController
{
    public function index()
    {
        $data['title'] = 'Login';
        return view('auth/index',$data);
    }
    public function register()
    {

    $data =[
        'title' =>'Buat Akun',
        'validate' => \Config\Services::validation()
    ];
    return view('auth/register', $data);
    }
}
