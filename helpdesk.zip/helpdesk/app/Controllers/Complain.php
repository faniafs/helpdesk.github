<?php

namespace App\Controllers;

use App\Models\ComplainModel;

class Complain extends BaseController
{
	protected $p;
	public function __construct()
	{
		$this->mModel = new ComplainModel();
	}
	public function index()
	{

		$skkp = $this->mModel->findAll();
		$data['title'] = 'Form Keluhan';
		$data['p'] = $skkp;
		return view('complain/index', $data);
	}
	public function savep()
	{
		$this->mModel->save([
			'email' => $this->request->getVar('email'),
			'divisi' => $this->request->getVar('divisi'),
			'perihal_masalah' => $this->request->getVar('perihal_masalah'),
			'deskripsi_masalah' => $this->request->getVar('deskripsi_masalah'),
			'status' => $this->request->getVar('status')
		]);
		session()->setFlashdata('pesan', 'File berhasil ditambahkan');
		return redirect()->to('/complain/myComplain');
	}
	public function deletep($id)
	{
		$this->mModel->delete($id);
		session()->setFlashdata('pesan', 'File berhasil dihapus ');
		return redirect()->to('/pengumuman');
	}
	public function downloadp($id)
	{

		$datafile = $this->mModel->find($id);
		return $this->response->download('file/pengumuman/' . $datafile->file, null);
	}
	public function myComplain()
	{

		$skkp = $this->mModel->where('email', session()->email)->findAll();
		$data['title'] = 'Keluhan Saya';
		$data['p'] = $skkp;
		return view('complain/mycomplain', $data);
	}
}
