<?php

namespace App\Controllers;

use App\Models\BackendModel;

class Backend extends BaseController
{
    public function __construct()
    {
        $this->authModel = new BackendModel();
    }
    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['total_user'] = $this->authModel->hitungJumlahUsers();
        $data['total_keluhan'] = $this->authModel->hitungJumlahkeluhan();
        return view('backend/index', $data);
    }
    public function changepassword()
    {
        session();
        $data = [
            'title' => 'Ubah Password'

        ];

        return view('backend/change-password', $data);
    }

    public function change($id)
    {
        if (!$this->validate([
            'current_password' => [
                'rules' => 'required|trim',
                'errors' => [
                    'required' => 'Harus Diisi'
                ]
            ],
            'new_password1' => [
                'rules' => 'required|trim|min_length[8]|matches[new_password2]',
                'errors' => [
                    'required' => 'Harus Diisi',
                    'min_length' => 'Minimal 8 Karakter',
                    'matches'  => 'Password Harus Sama'

                ]
            ],
            'new_password2' =>  [
                'rules' => 'required|trim|min_length[8]|matches[new_password1]',
                'errors' => [
                    'required' => 'Harus Diisi',
                    'min_length' => 'Minimal 8 Karakter',
                    'matches'  => 'Password Harus Sama'

                ]
            ],

        ])) {

            return redirect()->to('/user/changepassword')->withInput();
        }
        $user = $this->authModel->find($id);
        $current_password = $this->request->getVar('current_password');
        $new_password = $this->request->getVar('new_password1');
        $hashing = password_hash($new_password, PASSWORD_DEFAULT);
        $password = $user['password'];
        if (!password_verify($current_password, $password)) {

            session()->setFlashdata('gagal', 'Wrong Current Password!');
            return redirect()->to('/backend/changepassword');
        } else {
            if ($current_password == $new_password) {
                session()->setFlashdata('gagal', 'New Password cannot be the same as current Password ');
                return redirect()->to('/backend/changepassword');
            } else {
                $password_hash = password_hash($this->request->getPost('new_password1'), PASSWORD_DEFAULT);
                $this->authModel->save(
                    [
                        'id' =>  $id,
                        'password' => $password_hash
                    ]
                );
                session()->setFlashdata('pesan', 'Password berhasil Diubah');
                return redirect()->to('/backend/changepassword');
            }
        }
    }
    public function edit()
    {
        session();
        $data = [
            'title' => 'Ubah Profile',
            'validation' => \Config\Services::validation()
        ];

        return view('backend/edit', $data);
    }
    public function update($id)
    {
        $this->authModel->save([
            'id' =>  $id,
            'email' => $this->request->getVar('email'),
            'nama' => $this->request->getVar('nama'),
        ]);
        $upload = $_FILES['gambar']['name'];

        if ($upload) {
            if (!$this->validate([
                'gambar' => [
                    'rules' => 'uploaded[berkas]|mime_in[berkas,image/jpg,image/jpeg,image/gif,image/png]|max_size[berkas,2048]',
                    'errors' => [
                        'uploaded' => 'Harus Ada File yang diupload',
                        'mime_in' => 'File Extention Harus Berupa jpg,jpeg,gif,png',
                        'max_size' => 'Ukuran File Maksimal 2 MB'
                    ]
                ]
            ]));
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }
        $dataBerkas = $this->request->getFile('gambar');
        $fileName = $dataBerkas->getRandomName();
        $dataBerkas->move('img/profile/', $fileName);
        $this->authModel->save([
            'id' =>  $id,
            'nama' => $this->request->getVar('nama'),
            'email' => $this->request->getVar('email'),
            'gambar' => $fileName
        ]);

        session()->setFlashdata('success', 'Berkas Berhasil diupload');
        return redirect()->to('backend/edit');
    }
}
