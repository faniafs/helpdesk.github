<?php

namespace App\Controllers;

use App\Models\ComplainModel;
use App\Models\AuthModel;
use App\Models\BackendModel;

class Admin extends BaseController
{
    protected $db, $builder;
    public function __construct()
    {
        $this->db      = \Config\Database::connect();
        $this->builder = $this->db->table('users');
        $this->authModel = new AuthModel();
        $this->bModel = new BackendModel();
        $this->mModel = new ComplainModel();
        $this->builders = $this->db->table('tb_keluhan');
    }
    public function index()
    {
        $data['title'] = 'Kelola Pengguna';
        // $users = new \Myth\Auth\Models\UserModel();
        // $data['users'] = $users->findAll();

        $this->builder->select('users.id as userid, email, nama');
        $query = $this->builder->get();
        $data['users'] = $query->getResult();
        return view('admin/index', $data);
    }
    public function Remove($id)
    {
        $this->bModel->delete($id);
        session()->setFlashdata('pesan', 'Akun berhasil dihapus ');
        return redirect()->to('/admin/index');
    }
    public function complain()
    {
        $skkp = $this->mModel->findAll();
        $data['title'] = 'Data Keluhan';
        $data['p'] = $skkp;
        return view('admin/complain', $data);
    }
    public function print($id)
    {
        $this->builders->select('id, email, divisi, perihal_masalah, deskripsi_masalah, status, created_at, updated_at, deleted_at');
        $this->builders->where('id', $id);
        $query = $this->builders->get();
        $data['s'] = $query->getRow();
        $skkp = $this->mModel->find($id);
        $data['title'] = 'Complain';

        return view('admin/email', $data);
    }
    public function Delete($id)
    {
        $this->mModel->delete($id);
        session()->setFlashdata('pesan', 'Data berhasil dihapus ');
        return redirect()->to('/admin/complain');
    }
    public function read($id = 0)
    {
        $this->builders->select('id, email, kepada, subject, complain, status, created_at, updated_at, removed_at');
        $this->builders->where('id', $id);
        $query = $this->builders->get();
        $data['s'] = $query->getRow();
        $skkp = $this->mModel->find($id);
        $data['title'] = 'Complain';
        return view('admin/read', $data);
    }
    public function export()
    {
        $skkp = $this->mModel->findAll();
        $data['title'] = 'Daftar Komplain Kejaksaan Negeri';
        $data['p'] = $skkp;
        return view('admin/print', $data);
    }
    public function actionProses($id)
    {
        $this->mModel->save([
            'id' => $id,
            'status' => 2
        ]);
        $skkp = $this->mModel->findAll();
        $data['title'] = 'Data Keluhan';
        $data['p'] = $skkp;
        session()->setFlashdata('pesan', 'Data berhasil diubah ');
        return redirect()->to('/admin/complain');
    }
    public function actionSelesai($id)
    {
        $this->mModel->save([
            'id' => $id,
            'status' => 1
            
        ]);
        $skkp = $this->mModel->findAll();
        $data['title'] = 'Data Keluhan';
        $data['p'] = $skkp;
        session()->setFlashdata('pesan', 'Data berhasil diubah ');
            return redirect()->to('/admin/complain');
    }
}
